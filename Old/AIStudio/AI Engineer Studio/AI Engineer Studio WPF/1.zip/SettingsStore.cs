using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace AIEngineerStudio;
public sealed class AppSettings { public string ApiKey {get;set;}=""; public string BaseUrl {get;set;}="https://apiduck.sytes.net/v1"; public string Model {get;set;}="gpt-5.6-terra"; public string Theme {get;set;}="Graphite (по умолчанию)"; public string PromptTemplate {get;set;}="Ты — автономный senior-разработчик. Отвечай на русском языке и используй Markdown."; public double Temperature {get;set;}=.2; public int MaxTokens {get;set;}=8192; public string PythonPath {get;set;}="python"; }
public static class SettingsStore {
 static string Dir=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"AIEngineerStudio"); static string File=>Path.Combine(Dir,"settings.json");
 public static AppSettings Load(){try{if(!System.IO.File.Exists(File))return new();var s=JsonSerializer.Deserialize<AppSettings>(System.IO.File.ReadAllText(File))??new();s.ApiKey=Unprotect(s.ApiKey);return s;}catch{return new();}}
 public static void Save(AppSettings s){Directory.CreateDirectory(Dir);var copy=JsonSerializer.Deserialize<AppSettings>(JsonSerializer.Serialize(s))!;copy.ApiKey=Protect(copy.ApiKey);System.IO.File.WriteAllText(File,JsonSerializer.Serialize(copy,new JsonSerializerOptions{WriteIndented=true}));}
 static string Protect(string value){if(string.IsNullOrEmpty(value))return "";try{return Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(value),null,DataProtectionScope.CurrentUser));}catch{return value;}}
 static string Unprotect(string value){if(string.IsNullOrEmpty(value))return "";try{return Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(value),null,DataProtectionScope.CurrentUser));}catch{return value;}}
}
