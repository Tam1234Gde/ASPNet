"""Bridge between WPF and the supplied OpenAI-compatible neural-network logic.
Reads one JSON request from stdin and returns one JSON response to stdout.
"""
import json, sys, os
from pathlib import Path

def main():
    request = json.load(sys.stdin)
    api_key = request.get("api_key") or os.getenv("CVC_API_KEY")
    if not api_key:
        raise RuntimeError("Не задан API-ключ. Откройте Настройки приложения и сохраните CVC_API_KEY.")
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("Не установлен пакет openai. Выполните: python -m pip install openai") from exc
    # Identical protocol family to 'Логика работы с нейросетью.py'.
    client = OpenAI(api_key=api_key, base_url=request.get("base_url") or "https://apiduck.sytes.net/v1")
    system = request.get("system_prompt", "Ты — автономный senior-разработчик.")
    context = request.get("context", "")
    if context:
        system += "\n\nКонтекст выбранных файлов проекта:\n" + context
    system += ("\n\nРаботай аккуратно. Если нужно изменить файлы, сначала опиши план и покажи "
               "конкретный diff; не утверждай, что изменения уже записаны, если этого не происходило.")
    messages = [{"role": "system", "content": system}] + request.get("history", [])
    response = client.chat.completions.create(
        model=request.get("model", "gpt-5.6-terra"), messages=messages,
        temperature=float(request.get("temperature", 0.2)), max_tokens=int(request.get("max_tokens", 8192)),
    )
    print(json.dumps({"ok": True, "content": response.choices[0].message.content or ""}, ensure_ascii=False))

try:
    main()
except Exception as exc:
    print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
    sys.exit(1)
