param([switch]$Observe)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
# Probe the same OS lock before touching the stop flag.
& $python -c "from app.runtime import ProcessLock; lock=ProcessLock(); lock.__enter__(); lock.__exit__()"
if ($LASTEXITCODE -ne 0) { throw 'Bot already running or lock unavailable' }
Set-Content -Path '.\state\stop.request' -Value 'run' -Encoding UTF8
$arguments = '-m app.daemon --interval 60'
if (-not $Observe) { $arguments += ' --sandbox-trade' }
$process = Start-Process -FilePath $python -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput '.\state\daemon.stdout.log' -RedirectStandardError '.\state\daemon.stderr.log' -PassThru
Start-Sleep -Seconds 3
if ($process.HasExited) { throw 'Worker exited; inspect state\daemon.stderr.log' }
Write-Output ('Started worker PID=' + $process.Id + '; sandbox only. Monitor state\bot.log')
