import asyncio
import logging
from datetime import datetime, timezone
from decimal import Decimal
from time import monotonic
from .config import Settings
from .ai import AIClient
from .models import MarketSnapshot, Action, encode, quotation_to_decimal as dec
from .risk import CircuitBreaker
from .tbank import TBankClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

async def cycle(s, ai, broker):
    portfolio = await broker.portfolio()
    instruments, candles, books = [], {}, {}
    metadata = {}
    for uid in s.instrument_uids:
        item = await broker.instrument(uid)
        metadata[uid] = item
        prices = await broker.services.market_data.get_last_prices(instrument_id=[uid])
        instruments.append({"instrument_id": uid, "lot": item.lot,
                            "min_price_increment": str(dec(item.min_price_increment)),
                            "last_prices": encode(prices.last_prices)})
        candles[uid] = encode((await broker.candles(uid)).candles)
        books[uid] = encode(await broker.services.market_data.get_order_book(instrument_id=uid, depth=s.orderbook_depth))
    snapshot = MarketSnapshot(datetime.now(timezone.utc).isoformat(), instruments,
                              orderbooks=books, candles=candles,
                              positions=encode(portfolio.positions), portfolio=encode(portfolio))
    d = await ai.decide(snapshot)
    if d.instrument_id not in s.instrument_uids:
        raise ValueError("AI returned instrument outside allowlist")
    if d.action == Action.HOLD: return
    item = metadata[d.instrument_id]
    position = next((p for p in portfolio.positions if p.instrument_uid == d.instrument_id), None)
    lots = dec(position.quantity_lots) if position else Decimal(0)
    CircuitBreaker(Decimal(str(s.max_drawdown_rub)), Decimal(0)).validate(
        d, lot_size=item.lot, price_increment=dec(item.min_price_increment),
        position_lots=lots, max_lots=s.max_order_lots, allow_market=s.allow_market_orders)
    from tinkoff.invest import SecurityTradingStatus
    status = await broker.services.market_data.get_trading_status(instrument_id=d.instrument_id)
    if status.trading_status != SecurityTradingStatus.SECURITY_TRADING_STATUS_NORMAL_TRADING:
        raise ValueError("Trading session is not normal trading")
    if not status.api_trade_available_flag:
        raise ValueError("API trading unavailable")
    if d.price_limit is None and not status.market_order_available_flag:
        raise ValueError("Market orders unavailable")
    if d.price_limit is not None and not status.limit_order_available_flag:
        raise ValueError("Limit orders unavailable")
    start = monotonic()
    result = await broker.post_order(d.instrument_id, d.lots,
                                    d.action == Action.BUY or (d.action == Action.CLOSE and lots < 0), d.price_limit)
    logging.info("Order submitted: %s", result.order_id)
    # Никогда не переотправляем PostOrder при неизвестном результате исполнения.
    state = await broker.order_state(result.order_id)
    await ai.feedback({"order_id": result.order_id, "directive": encode(d),
                       "state": encode(state), "realized_pnl_rub": None,
                       "execution_delay_ms": int((monotonic()-start)*1000),
                       "delay_kind": "submission_and_state_query", "market_context": encode(snapshot)})
    logging.info("Execution telemetry captured; filled lots: %s", state.lots_executed)

async def run_once(s: Settings):
    if s.dry_run:
        logging.info("DRY_RUN: network and orders disabled; use python -m app.ai_check to check AI")
        return
    if not s.sandbox:
        raise RuntimeError("Production blocked: continuous circuit breaker/flatten and reconciliation are not implemented")
    if not s.instrument_uids:
        raise ValueError("INSTRUMENT_UIDS required")
    ai = AIClient(s)
    try:
        async with TBankClient(s) as broker:
            await cycle(s, ai, broker)
    finally:
        await ai.close()

def main():
    s = Settings()
    s.validate()
    asyncio.run(run_once(s))

if __name__ == "__main__": main()
