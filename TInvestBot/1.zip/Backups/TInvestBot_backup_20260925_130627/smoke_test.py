"""Безопасный smoke-test: проверяет конфигурацию и sandbox-клиент; заявки не отправляет.
Для реального sandbox E2E задайте DRY_RUN=false, IS_SANDBOX=true и используйте отдельный аккаунт.
"""
import asyncio
from decimal import Decimal
from app.config import Settings
from app.tbank import TBankClient

async def main():
    s = Settings(); s.validate()
    if not s.sandbox: raise SystemExit("Smoke test требует IS_SANDBOX=true")
    if s.dry_run: print("OK: dry-run, сеть и заявки отключены"); return
    async with TBankClient(s) as broker:
        await broker.sandbox_pay_in(Decimal(str(s.sandbox_initial_rub)))
        print("SandboxPayIn OK; укажите INSTRUMENT_UIDS для запроса свечей")
        for uid in s.instrument_uids:
            response = await broker.candles(uid)
            print(uid, len(response.candles), "candles")

if __name__ == "__main__": asyncio.run(main())
