@echo off
setlocal
cd /d "%~dp0"
if not exist state mkdir state
if not exist .env (
  echo ERROR: .env not found
  pause
  exit /b 2
)
if not exist .venv314\Scripts\python.exe (
  echo ERROR: Python environment .venv314 not found
  pause
  exit /b 3
)
echo Starting Telegram bot. Logs: state\telegram.stdout.log and state\telegram.stderr.log
".venv314\Scripts\python.exe" -m app.telegram >> state\telegram.stdout.log 2>> state\telegram.stderr.log
set ERR=%ERRORLEVEL%
echo Telegram stopped with code %ERR%
pause
exit /b %ERR%
