@echo off
cd /d "%~dp0"
rem Sandbox permission only; remote defaults remain paused/observe.
".venv314\Scripts\python.exe" -m app.daemon --sandbox-trade --resume --interval 60
pause
