# Подключение Telegram и прокси

## 1. Безопасность

Вставленная конфигурация содержит VLESS UUID и ключ Reality. Считайте её секретом и после публикации перевыпустите доступ у провайдера. Не пересылайте JSON в группы.

## 2. Переменные `.env`

```dotenv
TELEGRAM_BOT_TOKEN=токен_от_BotFather
TELEGRAM_ALLOWED_USER_IDS=ваш_числовой_ID
IS_SANDBOX=true
```

ID — только число, не username. Узнать его можно через `/id`, если ID уже разрешён, либо временно посмотреть `from.id` в диагностике.

## 3. Прокси Xray/VLESS

Сохраните полный JSON в Telegram сообщением такого вида:

```text
/vpn_json {"inbounds":[...],"outbounds":[...],"routing":{...}}
```

Для многострочного JSON Telegram может изменить формат, поэтому надёжнее сохранить JSON локально в `state/telegram_xray.json` (UTF-8). Бот валидирует `inbounds`, `outbounds`, HTTP-inbound и VLESS-outbound.

Установите `xray.exe` и укажите путь в `.env`:

```dotenv
XRAY_PATH=C:\\Tools\\xray\\xray.exe
VPN_CONFIG_PATH=state/telegram_xray.json
```

При старте бот запускает Xray только как дочерний локальный процесс и использует его HTTP-прокси только для Telegram. T-Invest/T-Bank SDK создаётся без proxy и идёт напрямую.

Если Xray уже запущен отдельно, можно не задавать `XRAY_PATH`, а указать:

```dotenv
TELEGRAM_PROXY=http://127.0.0.1:10809
```

## 4. Запуск батниками

1. Остановите старые копии (`STOP_BOT.bat`, закройте старые окна Telegram).
2. Для Telegram: `START_TELEGRAM.bat`.
3. Для демона Sandbox: `START_MANAGED_BOT.bat`.
4. Для обоих: `START_ALL.bat`.

В Telegram-логе должна появиться строка `TELEGRAM_CONNECTED`. Если её нет, смотрите `state/telegram.stderr.log`.

## 5. Проверка в Telegram

Отправьте боту в личном чате:

```text
/start
/id
/status
/vpn
```

Команды не работают в группах. Пользователь должен быть в `TELEGRAM_ALLOWED_USER_IDS`.

## 6. Торговый режим

По умолчанию бот наблюдает. `/resume` и `/mode sandbox` требуют `/confirm КОД`. Торговля возможна только в Sandbox и только при запуске демона с `--sandbox-trade`. Production заблокирован.

## 7. Типовые ошибки

- `TELEGRAM_HTTP_FAILED` — Telegram недоступен; проверьте Xray/HTTP proxy.
- `Conflict: terminated by other getUpdates request` — запущены две копии Telegram; оставьте одну.
- `Unauthorized` — неверный токен.
- Нет ответа на команды — проверьте личный чат и numeric ID.
- T-Invest ошибки при работающем Telegram — прокси не применяется к T-Invest; проверяйте сеть/токен отдельно.
