"""Optional Xray/VLESS launcher used only as Telegram's local proxy."""
from __future__ import annotations
import json
import logging
import os
import subprocess
from pathlib import Path

CONFIG_PATH = Path(os.getenv("VPN_CONFIG_PATH", "state/telegram_xray.json"))


def validate_config(value: object) -> dict:
    if not isinstance(value, dict):
        raise ValueError("Конфигурация должна быть JSON-объектом")
    for key in ("inbounds", "outbounds"):
        if not isinstance(value.get(key), list) or not value[key]:
            raise ValueError(f"Отсутствует непустой раздел {key}")
    inbounds = value["inbounds"]
    if not any(str(x.get("protocol", "")).lower() == "http" and int(x.get("port", 0)) > 0 for x in inbounds if isinstance(x, dict)):
        raise ValueError("Нужен HTTP-inbound для Telegram (например 127.0.0.1:10809)")
    if not any(isinstance(x, dict) and str(x.get("protocol", "")).lower() == "vless" for x in value["outbounds"]):
        raise ValueError("В outbounds не найден VLESS")
    return value


def save_config(value: object) -> str:
    config = validate_config(value)
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CONFIG_PATH)
    return str(CONFIG_PATH)


def local_http_proxy(value: dict) -> str:
    for inbound in value["inbounds"]:
        if isinstance(inbound, dict) and str(inbound.get("protocol", "")).lower() == "http":
            listen = inbound.get("listen", "127.0.0.1")
            port = int(inbound.get("port", 0))
            return f"http://{listen}:{port}"
    raise ValueError("HTTP-inbound не найден")


def load_config() -> dict | None:
    if not CONFIG_PATH.exists():
        return None
    return validate_config(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))


def start() -> tuple[subprocess.Popen | None, str | None]:
    config = load_config()
    if not config:
        return None, None
    executable = os.getenv("XRAY_PATH", "xray").strip()
    try:
        proc = subprocess.Popen([executable, "run", "-c", str(CONFIG_PATH)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except (FileNotFoundError, OSError) as exc:
        logging.warning("XRAY_NOT_STARTED path=%s type=%s", executable, type(exc).__name__)
        return None, local_http_proxy(config)
    logging.info("XRAY_STARTED pid=%s config=%s", proc.pid, CONFIG_PATH)
    return proc, local_http_proxy(config)


def stop(proc: subprocess.Popen | None) -> None:
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
