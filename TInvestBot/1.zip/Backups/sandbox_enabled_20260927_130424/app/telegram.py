"""Private-chat Telegram control and durable event delivery (long polling)."""
import asyncio
import json
import logging
import os
import secrets
import time
from pathlib import Path
import httpx
from .config import Settings
from .control import Control
from .tbank import TBankClient
from .models import encode
from .journal import Journal
from .runtime import ProcessLock
from .vpn import save_config, start as start_vpn, stop as stop_vpn, local_http_proxy

HELP = '''/status /settings /portfolio /orders /errors
/pause — запрет новых заявок, мониторинг продолжается
/resume — разрешить анализ (подтверждение)
/mode observe|sandbox — режим; production запрещён
/instruments — список UID и состояния
/search SBER — поиск инструментов
/add UID — добавить выключенным
/enable UID /disable UID
/set interval|max_order_lots|max_drawdown_rub|max_exposure_rub ЧИСЛО
/cancel ORDER_ID — отмена одной Sandbox-заявки (подтверждение)
/notify all|important|off
/id — показать ваш числовой Telegram ID
/confirm КОД — подтвердить за 60 секунд
/vpn — статус прокси
/vpn_json — следующей командой вставьте JSON-конфигурацию Xray
/start /help — справка. Запуск процессов выполняется на компьютере.'''

class Commands:
    def __init__(self, s, control, users):
        self.s, self.c, self.users = s, control, set(users)
        self.pending = {}

    async def handle(self, message):
        user = message.get('from', {}).get('id')
        chat = message.get('chat', {})
        if user not in self.users or chat.get('type') != 'private' or chat.get('id') != user:
            return None
        # Never execute old queued commands after an outage.
        if abs(time.time() - message.get('date', 0)) > 120:
            return 'Команда устарела; отправьте повторно.'
        text = message.get('text', '').strip()
        if user in getattr(self, 'vpn_pending', set()) and text.startswith('{'):
            self.vpn_pending.discard(user)
            try:
                path = save_config(json.loads(text))
                return f'VPN-конфигурация сохранена: {path}. Перезапустите START_TELEGRAM.bat.'
            except (json.JSONDecodeError, ValueError) as exc:
                return f'Некорректная VPN-конфигурация: {exc}'
        args = text.split()
        if not args:
            return HELP
        cmd = args[0].split('@')[0].lower()
        args = args[1:]
        try:
            if cmd == '/vpn_json':
                raw = text[len(args[0]) + 1:].strip() if False else text.split(' ', 1)[1].strip() if ' ' in text else ''
                if not raw:
                    self.vpn_pending = getattr(self, 'vpn_pending', set())
                    self.vpn_pending.add(user)
                    return 'Режим приёма включён. Отправьте следующим сообщением полный JSON одним сообщением.'
                try:
                    path = save_config(json.loads(raw))
                    return f'VPN-конфигурация сохранена: {path}. Перезапустите START_TELEGRAM.bat.'
                except (json.JSONDecodeError, ValueError) as exc:
                    return f'Некорректная VPN-конфигурация: {exc}'
            if cmd == '/confirm':
                pending = self.pending.pop(user, None)
                if not pending or len(args) != 1 or not secrets.compare_digest(args[0], pending[0]) or time.monotonic() > pending[1]:
                    return 'Неверное или просроченное подтверждение.'
                return await self.execute(pending[2], pending[3], user=user)
            if cmd in {'/resume','/enable','/set','/cancel'} or (cmd == '/mode' and args == ['sandbox']):
                code = secrets.token_hex(4)
                self.pending[user] = (code, time.monotonic()+60, cmd, args)
                return f'Подтвердите {cmd} {" ".join(args)}: /confirm {code} (60 секунд)'
            return await self.execute(cmd, args, user=user)
        except (ValueError, IndexError):
            return 'Некорректные параметры. /help'
        except Exception as exc:
            logging.warning('TELEGRAM_COMMAND_FAILED type=%s', type(exc).__name__)
            return 'Операция не подтверждена. Проверьте /status и /orders; не повторяйте отмену вслепую.'

    async def execute(self, cmd, args, user=None):
        if cmd in {'/help', '/start'}:
            return HELP
        if cmd == '/id' and not args:
            return f'Ваш числовой Telegram ID: {user}'
        if cmd == '/vpn' and not args:
            return 'Прокси задаётся только для Telegram. T-Invest API использует прямое соединение. Для настройки: /vpn_json + JSON, затем перезапустите Telegram.'
        if cmd == '/pause' and not args:
            self.c.put('paused', True)
            return 'Пауза сохранена. Уже отправленные заявки НЕ отменены, позиции НЕ закрыты.'
        if cmd == '/resume' and not args:
            self.c.put('paused', False)
            return 'Анализ разрешён. Заявки — только в sandbox и при запуске daemon с --sandbox-trade.'
        if cmd == '/mode' and len(args) == 1 and args[0] in {'observe','sandbox'}:
            self.c.put('mode', args[0])
            return 'Режим: ' + args[0]
        if cmd == '/notify' and len(args) == 1 and args[0] in {'all','important','off'}:
            self.c.put('notify', args[0])
            return 'Уведомления: ' + args[0]
        if cmd == '/set' and len(args) == 2:
            self.c.set_limit(*args)
            return 'Настройка сохранена; применяется со следующего цикла. Текущие решения при изменении лимитов отклоняются.'
        if cmd == '/settings':
            return json.dumps({k:self.c.get(k,v) for k,v in {'paused':True,'mode':'observe','interval':60,'max_order_lots':self.s.max_order_lots,'max_drawdown_rub':self.s.max_drawdown_rub,'max_exposure_rub':10000,'notify':'important'}.items()}, ensure_ascii=False, indent=2)
        if cmd == '/status':
            p = Path('state/status.json')
            return (p.read_text(encoding='utf-8') if p.exists() else 'Daemon ещё не запущен.') + '\n' + await self.execute('/settings', [])
        if cmd == '/instruments':
            return '\n'.join(f'{uid}: {"ON" if on else "OFF"}' for uid,on in self.c.instruments(self.s).items()) or 'Список пуст.'
        if cmd in {'/enable','/disable'} and len(args) == 1:
            items = self.c.instruments(self.s)
            if args[0] not in items:
                raise ValueError()
            items[args[0]] = cmd == '/enable'
            self.c.put('instruments', items)
            return 'Сохранено. Выключение запрещает новые заявки, но не отменяет существующие и не закрывает позиции.'
        if cmd == '/errors':
            j = Journal(self.s.journal_path)
            try:
                rows = j.db.execute("SELECT time,kind,payload FROM events WHERE kind IN ('ERROR','INSTRUMENT_ERROR','RISK_REJECTED') ORDER BY id DESC LIMIT 5").fetchall()
                return json.dumps(rows, ensure_ascii=False) if rows else 'Ошибок нет.'
            finally:
                j.close()
        if cmd in {'/portfolio','/orders','/search','/add','/cancel'}:
            if not self.s.sandbox:
                return 'Production запрещён.'
            async with TBankClient(self.s) as b:
                if cmd == '/portfolio':
                    return json.dumps(encode(await b.portfolio()), ensure_ascii=False)
                if cmd == '/orders':
                    return json.dumps(encode(await b.services.sandbox.get_sandbox_orders(account_id=self.s.account_id)), ensure_ascii=False)
                if cmd == '/search' and args:
                    result = await b.services.instruments.find_instrument(query=' '.join(args))
                    return '\n'.join(f'{i.ticker} {i.class_code} | {i.name} | {i.uid}' for i in result.instruments[:20]) or 'Не найдено.'
                if cmd == '/add' and len(args) == 1:
                    item = await b.instrument(args[0])
                    if item.instrument_type != 'share' or item.currency.lower() != 'rub':
                        return 'Поддерживаются только рублёвые акции (не фьючерсы/облигации).'
                    items = self.c.instruments(self.s)
                    if len(items) >= 30 and item.uid not in items:
                        return 'Максимум 30 инструментов.'
                    items.setdefault(item.uid, False)
                    self.c.put('instruments', items)
                    return f'{item.ticker}: {item.uid} добавлен. /enable {item.uid}'
                if cmd == '/cancel' and len(args) == 1:
                    active = await b.services.sandbox.get_sandbox_orders(account_id=self.s.account_id)
                    if args[0] not in {o.order_id for o in active.orders}:
                        return 'Заявка не найдена среди активных; проверьте исполнение.'
                    await b.services.sandbox.cancel_sandbox_order(account_id=self.s.account_id, order_id=args[0])
                    return 'Запрос отмены принят. Проверьте /orders; частичное исполнение возможно.'
        return 'Неизвестная команда или параметры. /help'

class TelegramAPI:
    def __init__(self, token):
        self.base = 'https://api.telegram.org/bot' + token
        proxy = os.getenv('TELEGRAM_PROXY', '').strip() or None
        # A proxy is optional and is useful when api.telegram.org is blocked.
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(40.0, connect=15.0),
            proxy=proxy,
            trust_env=True,
        )
        self.proxy_enabled = bool(proxy)

    async def call(self, method, **data):
        try:
            response = await self.client.post(self.base + '/' + method, json=data)
        except Exception as exc:
            logging.warning('TELEGRAM_HTTP_FAILED method=%s proxy=%s type=%s', method, self.proxy_enabled, type(exc).__name__)
            raise
        # Do not expose URLs containing bot token in exceptions/logging.
        if response.status_code != 200:
            raise RuntimeError(f'Telegram HTTP error {response.status_code}')
        result = response.json()
        if not result.get('ok'):
            description = str(result.get('description', 'unknown'))[:300]
            raise RuntimeError(f'Telegram API error: {description}')
        return result['result']

    async def send(self, chat, text):
        # Bound command replies and event messages.
        text = text[:12000]
        for start in range(0, len(text), 3000):
            await self.call('sendMessage', chat_id=chat, text=text[start:start+3000])

async def notifications(s, c, api, users):
    while True:
        try:
            j = Journal(s.journal_path)
            try:
                j.db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, time TEXT, kind TEXT, payload TEXT)')
                for user in users:
                    key = f'event_cursor_{user}'
                    cursor = c.get(key)
                    if cursor is None:
                        c.put(key, j.db.execute('SELECT COALESCE(MAX(id),0) FROM events').fetchone()[0])
                        continue
                    rows = j.db.execute('SELECT id,time,kind,payload FROM events WHERE id>? ORDER BY id LIMIT 10', (cursor,)).fetchall()
                    selected = []
                    mode = c.get('notify','important')
                    for row in rows:
                        if mode != 'off' and (row[2] in {'ORDER_SUBMITTED','ORDER_STATE','BROKER_OPERATION','ERROR','RISK_REJECTED','INSTRUMENT_ERROR','DAEMON_START','DAEMON_STOP'} or (mode == 'all' and row[2] == 'DECISION')):
                            selected.append(f'{row[1]} {row[2]}\n{row[3][:700]}')
                    if selected:
                        await api.send(user, '\n\n'.join(selected))
                    if rows:
                        c.put(key, rows[-1][0])
            finally:
                j.close()
        except Exception as exc:
            logging.warning('TELEGRAM_NOTIFY_FAILED type=%s', type(exc).__name__)
        await asyncio.sleep(15)

async def run():
    token = os.getenv('TELEGRAM_BOT_TOKEN','').strip()
    users = {int(x.strip()) for x in os.getenv('TELEGRAM_ALLOWED_USER_IDS','').split(',') if x.strip()}
    if not token or not users or any(x <= 0 for x in users):
        raise SystemExit('Set TELEGRAM_BOT_TOKEN and positive TELEGRAM_ALLOWED_USER_IDS in .env')
    s = Settings()
    if not s.sandbox:
        raise SystemExit('Production is blocked')
    c = Control()
    commands = Commands(s,c,users)
    vpn_proc = None
    vpn_proxy = None
    try:
        vpn_proc, vpn_proxy = start_vpn()
    except Exception as exc:
        logging.warning('VPN_CONFIG_FAILED type=%s', type(exc).__name__)
    if vpn_proxy and not os.getenv('TELEGRAM_PROXY', '').strip():
        api = TelegramAPI(token)
        await api.client.aclose()
        os.environ['TELEGRAM_PROXY'] = vpn_proxy
    api = TelegramAPI(token)
    task = asyncio.create_task(notifications(s,c,api,users))
    try:
        me = await api.call('getMe')
        logging.info('TELEGRAM_CONNECTED username=%s proxy=%s', me.get('username'), api.proxy_enabled)
        await api.call('deleteWebhook', drop_pending_updates=False)
        while True:
            try:
                updates = await api.call('getUpdates', offset=c.get('telegram_offset',0), timeout=25, allowed_updates=['message'])
                for update in updates:
                    # At-most-once command execution: commit receipt before side effects.
                    c.put('telegram_offset', update['update_id']+1)
                    message = update.get('message',{})
                    reply = await commands.handle(message)
                    if reply:
                        await api.send(message['chat']['id'],reply)
            except Exception as exc:
                logging.warning('TELEGRAM_POLL_FAILED type=%s detail=%s', type(exc).__name__, str(exc)[:300])
                await asyncio.sleep(10)
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        await api.client.aclose()
        stop_vpn(vpn_proc)

def main():
    logging.basicConfig(level=logging.INFO)
    logging.getLogger('httpx').setLevel(logging.CRITICAL)
    logging.getLogger('httpcore').setLevel(logging.CRITICAL)
    with ProcessLock('state/telegram.lock'):
        try:
            asyncio.run(run())
        except KeyboardInterrupt:
            pass

if __name__ == '__main__':
    main()
