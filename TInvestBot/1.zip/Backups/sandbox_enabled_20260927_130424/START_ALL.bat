@echo off
setlocal
cd /d "%~dp0"
start "TInvest Telegram" /min cmd /c call "%~dp0START_TELEGRAM.bat"
start "TInvest Daemon" cmd /c call "%~dp0START_MANAGED_BOT.bat"
echo Telegram and daemon started in separate windows.
