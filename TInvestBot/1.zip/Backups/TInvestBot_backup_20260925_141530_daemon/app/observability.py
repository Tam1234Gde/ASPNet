"""Unified console and file logging for operations."""
import logging
from pathlib import Path

def setup_logging():
    Path('state').mkdir(exist_ok=True)
    logging.basicConfig(level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s %(message)s',
        handlers=[logging.StreamHandler(), logging.FileHandler('state/bot.log', encoding='utf-8')],
        force=True)
