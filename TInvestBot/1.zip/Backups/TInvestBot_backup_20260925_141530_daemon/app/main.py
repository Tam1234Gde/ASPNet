import asyncio
import logging
from datetime import datetime, timezone
from decimal import Decimal
from time import monotonic
from .config import Settings
from .ai import AIClient
from .models import MarketSnapshot, Action, encode, quotation_to_decimal as dec
from .risk import CircuitBreaker
from .tbank import TBankClient

from .observability import setup_logging
setup_logging()

async def cycle(s, ai, broker):
    logging.info("CYCLE_START sandbox=%s dry_run=%s", s.sandbox, s.dry_run)
    portfolio = await broker.portfolio()
    instruments, candles, books = [], {}, {}
    metadata = {}
    for uid in s.instrument_uids:
        item = await broker.instrument(uid)
        uid = item.uid
        metadata[uid] = item
        prices = await broker.services.market_data.get_last_prices(instrument_id=[uid])
        instruments.append({"instrument_id": uid, "lot": item.lot,
                            "min_price_increment": str(dec(item.min_price_increment)),
                            "last_prices": encode(prices.last_prices)})
        candles[uid] = encode((await broker.candles(uid)).candles)
        books[uid] = encode(await broker.services.market_data.get_order_book(instrument_id=uid, depth=s.orderbook_depth))
    snapshot = MarketSnapshot(datetime.now(timezone.utc).isoformat(), instruments,
                              orderbooks=books, candles=candles,
                              positions=encode(portfolio.positions), portfolio=encode(portfolio))
    logging.info("SNAPSHOT_READY instruments=%s equity=%s", len(instruments), dec(portfolio.total_amount_portfolio))
    d = await ai.decide(snapshot)
    logging.info("DECISION action=%s instrument=%s lots=%s limit=%s confidence=%s", d.action, d.instrument_id, d.lots, d.price_limit, d.confidence)
    if d.instrument_id not in metadata:
        raise ValueError("AI returned instrument outside allowlist")
    if d.action == Action.HOLD:
        logging.info("HOLD: no order")
        return
    if s.dry_run:
        logging.info("DRY_RUN_DECISION: no order submitted; no simulated profit calculated")
        return
    if (datetime.now(timezone.utc) - datetime.fromisoformat(snapshot.timestamp)).total_seconds() > s.max_snapshot_age_seconds:
        raise ValueError("Snapshot expired")
    item = metadata[d.instrument_id]
    position = next((p for p in portfolio.positions if p.instrument_uid == d.instrument_id), None)
    lots = dec(position.quantity_lots) if position else Decimal(0)
    CircuitBreaker(Decimal(str(s.max_drawdown_rub)), Decimal(0)).validate(
        d, lot_size=item.lot, price_increment=dec(item.min_price_increment),
        position_lots=lots, max_lots=s.max_order_lots, allow_market=s.allow_market_orders)
    from t_tech.invest import SecurityTradingStatus
    status = await broker.services.market_data.get_trading_status(instrument_id=d.instrument_id)
    if status.trading_status != SecurityTradingStatus.SECURITY_TRADING_STATUS_NORMAL_TRADING:
        raise ValueError("Trading session is not normal trading")
    if not status.api_trade_available_flag:
        raise ValueError("API trading unavailable")
    if d.price_limit is None and not status.market_order_available_flag:
        raise ValueError("Market orders unavailable")
    if d.price_limit is not None and not status.limit_order_available_flag:
        raise ValueError("Limit orders unavailable")
    from .journal import Journal
    journal = Journal(s.journal_path)
    try:
        if journal.get("pending"):
            raise RuntimeError("Unresolved previous order: manual reconciliation required")
        journal.put("pending", {"directive": encode(d), "time": datetime.now(timezone.utc).isoformat()})
    finally:
        journal.close()
    start = monotonic()
    result = await broker.post_order(d.instrument_id, d.lots,
                                    d.action == Action.BUY or (d.action == Action.CLOSE and lots < 0), d.price_limit)
    logging.info("Order submitted: %s", result.order_id)
    journal = Journal(s.journal_path)
    try:
        journal.put("pending", {"order_id": result.order_id, "directive": encode(d)})
    finally:
        journal.close()
    # Никогда не переотправляем PostOrder при неизвестном результате исполнения.
    state = await broker.order_state(result.order_id)
    logging.info("ORDER_STATE id=%s status=%s filled=%s requested=%s commission=%s", result.order_id, state.execution_report_status.name, state.lots_executed, state.lots_requested, dec(state.executed_commission))
    journal = Journal(s.journal_path)
    try:
        journal.put("last_order", encode(state))
        if state.execution_report_status.name in {"EXECUTION_REPORT_STATUS_FILL", "EXECUTION_REPORT_STATUS_REJECTED", "EXECUTION_REPORT_STATUS_CANCELLED"}:
            journal.put("pending", None)
    finally:
        journal.close()
    await ai.feedback({"order_id": result.order_id, "directive": encode(d),
                       "state": encode(state), "realized_pnl_rub": None,
                       "execution_delay_ms": int((monotonic()-start)*1000),
                       "delay_kind": "submission_and_state_query", "market_context": encode(snapshot)})
    logging.info("Execution telemetry captured; filled lots: %s", state.lots_executed)

async def run_once(s: Settings, online=False):
    if s.dry_run and not online:
        logging.info("DRY_RUN: network and orders disabled; use python -m app.ai_check to check AI")
        return
    if not s.sandbox:
        raise RuntimeError("Production blocked: continuous circuit breaker/flatten and reconciliation are not implemented")
    if not s.instrument_uids:
        raise ValueError("INSTRUMENT_UIDS required")
    ai = AIClient(s)
    try:
        async with TBankClient(s) as broker:
            await cycle(s, ai, broker)
    finally:
        await ai.close()

def main():
    import argparse
    from dataclasses import replace
    parser = argparse.ArgumentParser()
    parser.add_argument("--observe", action="store_true", help="One online AI cycle, orders forcibly disabled")
    args = parser.parse_args()
    s = Settings()
    if args.observe:
        s = replace(s, dry_run=True)
    s.validate()
    try:
        asyncio.run(asyncio.wait_for(run_once(s, online=args.observe), timeout=max(90, s.ai_timeout + 60)))
        logging.info("RUN_COMPLETE: one cycle finished; process exits")
    except Exception as exc:
        logging.error("RUN_FAILED type=%s; no automatic retry; inspect account before restart", type(exc).__name__)
        raise SystemExit(1)

if __name__ == "__main__": main()
