"""Private-chat Telegram control and durable event delivery (long polling)."""
import asyncio
import json
import logging
import os
import secrets
import time
from pathlib import Path
import httpx
from .config import Settings
from .control import Control
from .tbank import TBankClient
from .models import encode
from .journal import Journal
from .runtime import ProcessLock
from .vpn import save_config, start as start_vpn, stop as stop_vpn, local_http_proxy
from .instruments import fetch_rub_instruments

INSTRUMENT_LIST_PATH = Path(__file__).resolve().parents[1] / 'instrumentlist.json'


def _load_instrument_list():
    if not INSTRUMENT_LIST_PATH.exists():
        return []
    try:
        data = json.loads(INSTRUMENT_LIST_PATH.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError):
        return []
    return data.get('instruments', []) if isinstance(data, dict) else data if isinstance(data, list) else []

HELP = '''Команды бота:
/status — состояние бота, режим и пауза
/balance — деньги на счёте и доступный остаток
/portfolio — позиции, лоты и прибыль/убыток
/orders — активные заявки Sandbox
/transactions — последние операции
/instruments — мои инструменты: ON/OFF и лимит лотов
/search ТЕКСТ — найти доступный инструмент
/add UID — добавить инструмент выключенным
/enable UID /disable UID — включить/выключить инструмент
/sync_instruments — обновить каталог рублёвых инструментов
/list_instruments — список из instrumentlist.json
/enable_list — добавить и включить доступные инструменты из instrumentlist.json
/set interval ЧИСЛО — интервал торгового цикла, 30–3600 сек
/set notify_interval ЧИСЛО — отчёт по транзакциям, 60–86400 сек
/set max_order_lots ЧИСЛО — максимум 1–10 лотов
/settings — текущие настройки
/pause /resume — пауза или возобновление (подтверждение)
/mode observe|sandbox — режим, production запрещён
/notify all|important|off — фильтр уведомлений
/cancel ORDER_ID — отмена заявки (подтверждение)
/id — показать Telegram ID
/vpn — статус прокси; /vpn_json — настроить прокси
/start /help — эта справка'''

KEYBOARD = {'keyboard': [['📊 Статус', '💰 Баланс'], ['📈 Портфель', '🧰 Инструменты'], ['🧾 Транзакции', '⚙️ Настройки'], ['⏸ Пауза', '▶️ Возобновить'], ['❓ Помощь']], 'resize_keyboard': True}


def _money(value):
    if value is None:
        return '—'
    if isinstance(value, dict):
        value = value.get('units', 0) + value.get('nano', 0) / 1_000_000_000
    try:
        return f'{float(value):,.2f}'.replace(',', ' ') + ' ₽'
    except (TypeError, ValueError):
        return str(value)


def _num(value):
    if isinstance(value, dict):
        return value.get('units', 0) + value.get('nano', 0) / 1_000_000_000
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0


def _field(obj, *names, default=None):
    for name in names:
        if isinstance(obj, dict) and name in obj:
            return obj[name]
        if hasattr(obj, name):
            return getattr(obj, name)
    return default


def _portfolio_text(portfolio):
    total = _field(portfolio, 'total_amount_currencies', 'total_amount', default=[])
    lines = ['💰 Счёт']
    if isinstance(total, (list, tuple)):
        for item in total:
            lines.append(f"{_field(item, 'currency', default='RUB').upper()}: {_money(_field(item, 'amount', default=item))}")
    positions = _field(portfolio, 'positions', default=[]) or []
    lines.append(f'\n📈 Позиции: {len(positions)}')
    if not positions:
        lines.append('Позиций нет.')
    for p in positions:
        uid = _field(p, 'instrument_uid', 'figi', default='?')
        lots = _num(_field(p, 'quantity', 'balance', default=0))
        pnl = _field(p, 'expected_yield', 'profit_loss', default=None)
        avg = _field(p, 'average_position_price', 'average_price', default=None)
        lines.append(f'{uid}: {lots:g} лот(ов), средняя {_money(avg)}, ' + ('прибыль ' if _num(pnl) >= 0 else 'убыток ') + _money(pnl))
    return '\n'.join(lines)

class Commands:
    def __init__(self, s, control, users):
        self.s, self.c, self.users = s, control, set(users)
        self.pending = {}

    async def handle(self, message):
        user = message.get('from', {}).get('id')
        chat = message.get('chat', {})
        if user not in self.users or chat.get('type') != 'private' or chat.get('id') != user:
            return None
        # Never execute old queued commands after an outage.
        if abs(time.time() - message.get('date', 0)) > 120:
            return 'Команда устарела; отправьте повторно.'
        text = message.get('text', '').strip()
        text = {'📊 Статус':'/status','💰 Баланс':'/balance','📈 Портфель':'/portfolio','🧰 Инструменты':'/instruments','🧾 Транзакции':'/transactions','⏸ Пауза':'/pause','▶️ Возобновить':'/resume','⚙️ Настройки':'/settings','❓ Помощь':'/help'}.get(text, text)
        if user in getattr(self, 'vpn_pending', set()) and text.startswith('{'):
            self.vpn_pending.discard(user)
            try:
                path = save_config(json.loads(text))
                return f'VPN-конфигурация сохранена: {path}. Перезапустите START_TELEGRAM.bat.'
            except (json.JSONDecodeError, ValueError) as exc:
                return f'Некорректная VPN-конфигурация: {exc}'
        args = text.split()
        if not args:
            return HELP
        cmd = args[0].split('@')[0].lower()
        args = args[1:]
        try:
            if cmd == '/vpn_json':
                raw = text[len(args[0]) + 1:].strip() if False else text.split(' ', 1)[1].strip() if ' ' in text else ''
                if not raw:
                    self.vpn_pending = getattr(self, 'vpn_pending', set())
                    self.vpn_pending.add(user)
                    return 'Режим приёма включён. Отправьте следующим сообщением полный JSON одним сообщением.'
                try:
                    path = save_config(json.loads(raw))
                    return f'VPN-конфигурация сохранена: {path}. Перезапустите START_TELEGRAM.bat.'
                except (json.JSONDecodeError, ValueError) as exc:
                    return f'Некорректная VPN-конфигурация: {exc}'
            if cmd == '/confirm':
                pending = self.pending.pop(user, None)
                if not pending or len(args) != 1 or not secrets.compare_digest(args[0], pending[0]) or time.monotonic() > pending[1]:
                    return 'Неверное или просроченное подтверждение.'
                return await self.execute(pending[2], pending[3], user=user)
            if cmd in {'/resume','/enable','/set','/cancel'} or (cmd == '/mode' and args == ['sandbox']):
                code = secrets.token_hex(4)
                self.pending[user] = (code, time.monotonic()+60, cmd, args)
                return f'Подтвердите {cmd} {" ".join(args)}: /confirm {code} (60 секунд)'
            return await self.execute(cmd, args, user=user)
        except (ValueError, IndexError):
            return 'Некорректные параметры. /help'
        except Exception as exc:
            logging.warning('TELEGRAM_COMMAND_FAILED type=%s', type(exc).__name__)
            return 'Операция не подтверждена. Проверьте /status и /orders; не повторяйте отмену вслепую.'

    async def execute(self, cmd, args, user=None):
        if cmd in {'/help', '/start'}:
            return HELP
        if cmd in {'/list_instruments', '/enable_list'} and not args:
            source = _load_instrument_list()
            if not source:
                return 'instrumentlist.json не найден или пуст.'
            rows = [x for x in source if isinstance(x, dict) and x.get('uid')]
            current = self.c.instruments(self.s)
            added = 0
            skipped = 0
            display = []
            for item in rows:
                uid = item['uid']
                name = item.get('ticker') or item.get('name') or uid
                tradable = item.get('buyAvailableFlag', True) and item.get('sellAvailableFlag', True)
                if cmd == '/enable_list' and tradable and (uid in current or len(current) < 30):
                    if uid not in current:
                        added += 1
                    current[uid] = True
                elif cmd == '/enable_list':
                    skipped += 1
                if cmd == '/list_instruments':
                    current_state = 'ON' if current.get(uid, False) else 'OFF'
                    display.append(f'{name} | {uid} | {current_state}')
            if cmd == '/enable_list':
                self.c.put('instruments', current)
                return f'Из списка добавлено и включено: {added}. Пропущено: {skipped}. Лимит: 30 инструментов.'
            return 'Инструменты из instrumentlist.json:\n' + '\n'.join(display)[:11000]
        if cmd == '/sync_instruments' and not args:
            items = await fetch_rub_instruments(self.s)
            current = self.c.instruments(self.s)
            for item in items:
                current.setdefault(item.uid, False)
            self.c.put('instruments', current)
            return f'Добавлено доступных инструментов: {len(items)}. Включайте нужные через /enable UID.'
        if cmd == '/transactions' and not args:
            p = Path('state/transactions.jsonl')
            rows = p.read_text(encoding='utf-8').splitlines()[-10:] if p.exists() else []
            return '\n'.join(rows) if rows else 'Транзакций нет.'
        if cmd == '/balance' and not args:
            if not self.s.sandbox:
                return 'Production запрещён.'
            async with TBankClient(self.s) as b:
                portfolio = await b.portfolio()
                return _portfolio_text(portfolio).split('\n📈 Позиции:', 1)[0]

        if cmd == '/id' and not args:
            return f'Ваш числовой Telegram ID: {user}'
        if cmd == '/vpn' and not args:
            return 'Прокси задаётся только для Telegram. T-Invest API использует прямое соединение. Для настройки: /vpn_json + JSON, затем перезапустите Telegram.'
        if cmd == '/pause' and not args:
            self.c.put('paused', True)
            return 'Пауза сохранена. Уже отправленные заявки НЕ отменены, позиции НЕ закрыты.'
        if cmd == '/resume' and not args:
            self.c.put('paused', False)
            return 'Анализ разрешён. Заявки — только в sandbox и при запуске daemon с --sandbox-trade.'
        if cmd == '/mode' and len(args) == 1 and args[0] in {'observe','sandbox'}:
            self.c.put('mode', args[0])
            return 'Режим: ' + args[0]
        if cmd == '/notify' and len(args) == 1 and args[0] in {'all','important','off'}:
            self.c.put('notify', args[0])
            return 'Уведомления: ' + args[0]
        if cmd == '/set' and len(args) == 2:
            self.c.set_limit(*args)
            return 'Настройка сохранена; применяется со следующего цикла. Текущие решения при изменении лимитов отклоняются.'
        if cmd == '/settings':
            return json.dumps({k:self.c.get(k,v) for k,v in {'paused':True,'mode':'observe','interval':60,'notify_interval':300,'max_order_lots':self.s.max_order_lots,'max_drawdown_rub':self.s.max_drawdown_rub,'max_exposure_rub':10000,'notify':'important'}.items()}, ensure_ascii=False, indent=2)
        if cmd == '/status':
            p = Path('state/status.json')
            return (p.read_text(encoding='utf-8') if p.exists() else 'Daemon ещё не запущен.') + '\n' + await self.execute('/settings', [])
        if cmd == '/instruments':
            return 'Лимит: максимум 10 лотов на инструмент.\n' + '\n'.join(f'{uid}: {"ON" if on else "OFF"}' for uid,on in self.c.instruments(self.s).items()) or 'Список пуст.'
        if cmd in {'/enable','/disable'} and len(args) == 1:
            items = self.c.instruments(self.s)
            if args[0] not in items:
                raise ValueError()
            items[args[0]] = cmd == '/enable'
            self.c.put('instruments', items)
            return 'Сохранено. Выключение запрещает новые заявки, но не отменяет существующие и не закрывает позиции.'
        if cmd == '/errors':
            j = Journal(self.s.journal_path)
            try:
                rows = j.db.execute("SELECT time,kind,payload FROM events WHERE kind IN ('ERROR','INSTRUMENT_ERROR','RISK_REJECTED') ORDER BY id DESC LIMIT 5").fetchall()
                return json.dumps(rows, ensure_ascii=False) if rows else 'Ошибок нет.'
            finally:
                j.close()
        if cmd in {'/portfolio','/orders','/search','/add','/cancel'}:
            if not self.s.sandbox:
                return 'Production запрещён.'
            async with TBankClient(self.s) as b:
                if cmd == '/portfolio':
                    return _portfolio_text(encode(await b.portfolio()))
                if cmd == '/orders':
                    return json.dumps(encode(await b.services.sandbox.get_sandbox_orders(account_id=self.s.account_id)), ensure_ascii=False)
                if cmd == '/search' and args:
                    result = await b.services.instruments.find_instrument(query=' '.join(args))
                    return '\n'.join(f'{i.ticker} {i.class_code} | {i.name} | {i.uid}' for i in result.instruments[:20]) or 'Не найдено.'
                if cmd == '/add' and len(args) == 1:
                    item = await b.instrument(args[0])
                    if item.instrument_type != 'share' or item.currency.lower() != 'rub':
                        return 'Поддерживаются только рублёвые акции (не фьючерсы/облигации).'
                    items = self.c.instruments(self.s)
                    if len(items) >= 30 and item.uid not in items:
                        return 'Максимум 30 инструментов.'
                    items.setdefault(item.uid, False)
                    self.c.put('instruments', items)
                    return f'{item.ticker}: {item.uid} добавлен. /enable {item.uid}'
                if cmd == '/cancel' and len(args) == 1:
                    active = await b.services.sandbox.get_sandbox_orders(account_id=self.s.account_id)
                    if args[0] not in {o.order_id for o in active.orders}:
                        return 'Заявка не найдена среди активных; проверьте исполнение.'
                    await b.services.sandbox.cancel_sandbox_order(account_id=self.s.account_id, order_id=args[0])
                    return 'Запрос отмены принят. Проверьте /orders; частичное исполнение возможно.'
        return 'Неизвестная команда или параметры. /help'

class TelegramAPI:
    def __init__(self, token):
        self.base = 'https://api.telegram.org/bot' + token
        proxy = os.getenv('TELEGRAM_PROXY', '').strip() or None
        # A proxy is optional and is useful when api.telegram.org is blocked.
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(40.0, connect=15.0),
            proxy=proxy,
            trust_env=True,
        )
        self.proxy_enabled = bool(proxy)

    async def call(self, method, **data):
        try:
            response = await self.client.post(self.base + '/' + method, json=data)
        except Exception as exc:
            logging.warning('TELEGRAM_HTTP_FAILED method=%s proxy=%s type=%s', method, self.proxy_enabled, type(exc).__name__)
            raise
        # Do not expose URLs containing bot token in exceptions/logging.
        if response.status_code != 200:
            raise RuntimeError(f'Telegram HTTP error {response.status_code}')
        result = response.json()
        if not result.get('ok'):
            description = str(result.get('description', 'unknown'))[:300]
            raise RuntimeError(f'Telegram API error: {description}')
        return result['result']

    async def send(self, chat, text, keyboard=False):
        # Bound command replies and event messages.
        text = text[:12000]
        for start in range(0, len(text), 3000):
            data = {'chat_id': chat, 'text': text[start:start+3000]}
            if keyboard and start == 0:
                data['reply_markup'] = KEYBOARD
            await self.call('sendMessage', **data)

async def notifications(s, c, api, users):
    while True:
        try:
            j = Journal(s.journal_path)
            try:
                j.db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, time TEXT, kind TEXT, payload TEXT)')
                for user in users:
                    key = f'event_cursor_{user}'
                    cursor = c.get(key)
                    if cursor is None:
                        c.put(key, j.db.execute('SELECT COALESCE(MAX(id),0) FROM events').fetchone()[0])
                        continue
                    rows = j.db.execute('SELECT id,time,kind,payload FROM events WHERE id>? ORDER BY id LIMIT 10', (cursor,)).fetchall()
                    selected = []
                    mode = c.get('notify','important')
                    for row in rows:
                        if mode != 'off' and (row[2] in {'ORDER_SUBMITTED','ORDER_STATE','BROKER_OPERATION','ERROR','RISK_REJECTED','INSTRUMENT_ERROR','DAEMON_START','DAEMON_STOP'} or (mode == 'all' and row[2] == 'DECISION')):
                            selected.append(f'{row[1]} {row[2]}\n{row[3][:700]}')
                    if selected:
                        compact = []
                        for row in selected:
                            payload = row.split('\n', 1)[-1]
                            try:
                                data = json.loads(payload)
                                compact.append(f"{row.split()[0]} {row.split()[1]}: {data.get('instrument', data.get('instrument_id', 'операция'))} {data.get('action', data.get('status', 'обновление'))}")
                            except Exception:
                                compact.append(row.split('\n', 1)[0] + ' ' + row.split('\n', 1)[-1][:120])
                        await api.send(user, 'Транзакции за последние 5 минут:\n' + '\n'.join(compact))
                    if rows:
                        c.put(key, rows[-1][0])
            finally:
                j.close()
        except Exception as exc:
            logging.warning('TELEGRAM_NOTIFY_FAILED type=%s', type(exc).__name__)
        await asyncio.sleep(max(60, int(c.get('notify_interval', 300))))

async def run():
    token = os.getenv('TELEGRAM_BOT_TOKEN','').strip()
    users = {int(x.strip()) for x in os.getenv('TELEGRAM_ALLOWED_USER_IDS','').split(',') if x.strip()}
    if not token or not users or any(x <= 0 for x in users):
        raise SystemExit('Set TELEGRAM_BOT_TOKEN and positive TELEGRAM_ALLOWED_USER_IDS in .env')
    s = Settings()
    if not s.sandbox:
        raise SystemExit('Production is blocked')
    c = Control()
    commands = Commands(s,c,users)
    vpn_proc = None
    vpn_proxy = None
    try:
        vpn_proc, vpn_proxy = start_vpn()
    except Exception as exc:
        logging.warning('VPN_CONFIG_FAILED type=%s', type(exc).__name__)
    if vpn_proxy and not os.getenv('TELEGRAM_PROXY', '').strip():
        api = TelegramAPI(token)
        await api.client.aclose()
        os.environ['TELEGRAM_PROXY'] = vpn_proxy
    api = TelegramAPI(token)
    task = asyncio.create_task(notifications(s,c,api,users))
    try:
        me = await api.call('getMe')
        logging.info('TELEGRAM_CONNECTED username=%s proxy=%s', me.get('username'), api.proxy_enabled)
        await api.call('deleteWebhook', drop_pending_updates=False)
        while True:
            try:
                updates = await api.call('getUpdates', offset=c.get('telegram_offset',0), timeout=25, allowed_updates=['message'])
                for update in updates:
                    # At-most-once command execution: commit receipt before side effects.
                    c.put('telegram_offset', update['update_id']+1)
                    message = update.get('message',{})
                    reply = await commands.handle(message)
                    if reply:
                        await api.send(message['chat']['id'], reply, keyboard=message.get('text','').strip() in {'/start','/help'})
            except Exception as exc:
                logging.warning('TELEGRAM_POLL_FAILED type=%s detail=%s', type(exc).__name__, str(exc)[:300])
                await asyncio.sleep(10)
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        await api.client.aclose()
        stop_vpn(vpn_proc)

def main():
    logging.basicConfig(level=logging.INFO)
    logging.getLogger('httpx').setLevel(logging.CRITICAL)
    logging.getLogger('httpcore').setLevel(logging.CRITICAL)
    with ProcessLock('state/telegram.lock'):
        try:
            asyncio.run(run())
        except KeyboardInterrupt:
            pass

if __name__ == '__main__':
    main()
